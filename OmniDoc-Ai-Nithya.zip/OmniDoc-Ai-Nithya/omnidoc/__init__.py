"""OmniDoc AI - Multimodal Document QA Application"""
__version__ = "1.0.0"
